package com.ancientmc.excavator.object;

import com.ancientmc.commons.StringUtil;
import com.ancientmc.commons.Util;
import com.ancientmc.commons.codec.Codecs;
import com.mojang.serialization.Codec;
import org.jspecify.annotations.NonNull;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Stream;

import static com.ancientmc.commons.codec.FieldCodecs.*;

/**
 * Represents an instance of a library object in the version JSON.
 *
 * @author moist-mason
 * @param name The name of this library (AKA the maven path).
 * @param downloads A subobject containing URLs for this library's artifact(s).
 * @param rules Specifications that dictates whether the game launcher downloads the artifacts for this library. Primarily
 * used for differentiating libraries that need to be downloaded on Mac only. If the rules object is not present, the library's artifact(s)
 * gets downloaded on all operating systems.
 *
 */
public record Library(String name, Downloads downloads, Optional<List<Rule>> rules) {
    public static final Codec<Library> CODEC = Codecs.of(Library::new,
            stringField(Library::name, "name"),
            field(Library::downloads, "downloads", Downloads.CODEC),
            optionalListField(Library::rules, "rules", Rule.CODEC)
    );

    /**
     * Checks if this library's artifacts are allowed for downloading.
     *
     * @return {@code true} if the rules allow the artifacts to be downloaded. If no rule object is present in this particular
     * library, the method defaults to {@code true}.
     */
    public boolean isAllowed() {
        return rules.map(r -> r.stream().anyMatch(Rule::isAllowed))
                .orElse(true);
    }

    /**
     * Gets all artifacts for this library object.
     *
     * @return The artifacts.
     */
    private List<Artifact> artifacts() {
        if (isAllowed()) {
            List<Artifact> artifacts = new ArrayList<>();

            downloads.artifact().ifPresent(artifacts::add);
            downloads.classifiers().ifPresent(c -> artifacts.add(c.artifact()));
            return artifacts;
        } else {
            return Collections.emptyList();
        }
    }

    /**
     * Gets the Java class library artifacts for this library object.
     *
     * @return The artifacts.
     */
    public List<Artifact> libraryArtifacts() {
        return Util.filteredList(artifacts(), a -> !a.isNative());
    }

    /**
     * Gets the native library artifacts for this library object.
     *
     * @return The artifacts.
     */
    public List<Artifact> nativeArtifacts() {
        return Util.filteredList(artifacts(), Artifact::isNative);
    }

    /**
     * A subobject containing download information for a particular library entry.
     *
     * @param classifiers An object containing download information for natives. Only in older versions.
     * @param artifact An object containing download information for the primary artifact of the "Downloads" object.
     */
    public record Downloads(Optional<Classifiers> classifiers, Optional<Artifact> artifact) {
        public static final Codec<Downloads> CODEC = Codecs.of(Downloads::new,
                optionalField(Downloads::classifiers, "classifiers", Classifiers.CODEC),
                optionalField(Downloads::artifact, "artifact", Artifact.CODEC)
        );
    }

    /**
     * Representation of an object containing the raw download information for a particular artifact.
     *
     * @param path The relative path for the artifact in a file tree.
     * @param url The URL of the artifact, usually from Mojang's servers.
     */
    public record Artifact(String path, URL url) {
        public static final Codec<Artifact> CODEC = Codecs.of(Artifact::new,
                stringField(Artifact::path, "path"),
                urlField(Artifact::url, "url")
        );

        /**
         * Checks if the artifact is for native libraries.
         *
         * @return {@code true} if the artifact is for natives.
         */
        public boolean isNative() {

            /*
             * Don't use "unix" here, because there is a Netty library in modern versions called "netty-transport-native-unix-common"
             * that doesn't contain natives at all. It's a class library, so it needs to be treated as such.
             */
            final List<String> commonOsNames = List.of("windows", "osx", "macos", "linux"); // TODO: refactor after refactoring Util.Os in commons
            return path.contains("native") && StringUtil.containsAny(commonOsNames, path);
        }
    }

    /**
     * Versions prior to 1.19 had a "classifiers" block that dictated natives associated with a particular library.
     *
     * @param windowsNatives
     * @param macNatives
     * @param linuxNatives
     */
    public record Classifiers(Optional<Artifact> windowsNatives, Optional<Artifact> macNatives, Optional<Artifact> linuxNatives) {
        public static final Codec<Classifiers> CODEC = Codecs.of(Classifiers::new,
                optionalField(Classifiers::windowsNatives, "natives-windows", Artifact.CODEC),
                optionalField(Classifiers::macNatives, "natives-osx", Artifact.CODEC),
                optionalField(Classifiers::linuxNatives, "natives-linux", Artifact.CODEC)
        );

        /**
         * Gets the artifact based on the OS.
         *
         * @return The artifact.
         */
        public Artifact artifact() {
            return switch (Util.os()) {
                case WINDOWS -> windowsNatives.orElseThrow();
                case MACOS -> macNatives.orElseThrow();
                case LINUX -> linuxNatives.orElseThrow();
                case UNKNOWN -> throw new RuntimeException("OS not found! How?");
            };
        }
    }
    /**
     * A subobject found in some library entries consisting of rules that dictate whether the library artifacts get downloaded.
     * This involves specifying the allowed (or disallowed) OS(s) for this particular library.
     * Each rule entry conists of an action state that tells the launcher whether it is allowed or disallowed to download
     * the artifact, and an OS marker that the action applies to.
     *
     * @param action The state of the rule. Either "allow" or "disallow".
     * @param os The OS the action applies to.
     */
    public record Rule(String action, Optional<Os> os) {
        public static final Codec<Rule> CODEC = Codecs.of(Rule::new,
                stringField(Rule::action, "action"),
                optionalField(Rule::os, "os", Os.CODEC)
        );

        /**
         * Determines if the rule is allowed for the user's OS.
         *
         * @return {@code true} if the rule is allowed.
         */
        public boolean isAllowed() {
            if (action.equals("disallow")) return false;
            return os.map(osEntry -> osEntry.name.equals(Util.os().getName())).orElse(true);
        }

        /**
         * Contains information about what OS the action applies to.
         *
         * @param name The name of the OS.
         */
        public record Os(String name) {
            public static final Codec<Os> CODEC = Codecs.of(Os::new,
                    stringField(Os::name, "name")
            );
        }
    }
}
