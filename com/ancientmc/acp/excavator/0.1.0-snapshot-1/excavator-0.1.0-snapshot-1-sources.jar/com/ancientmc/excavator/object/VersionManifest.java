package com.ancientmc.excavator.object;

import com.ancientmc.commons.Util;
import com.ancientmc.commons.codec.Codecs;
import com.mojang.serialization.Codec;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;

import static com.ancientmc.commons.codec.FieldCodecs.*;

/**
 * Represents the version manifest JSON.
 * @param latest Object containing the latest release and snapshot version numbers.
 * @param versions The array list of Minecraft versions.
 * @author moist-mason
 */
public record VersionManifest(Optional<Latest> latest, List<Version> versions) {
    public static final Codec<VersionManifest> CODEC = Codecs.of(VersionManifest::new,
            optionalField(VersionManifest::latest, "latest", Latest.CODEC),
            listField(VersionManifest::versions, "versions", Version.CODEC)
    );

    /**
     * Deserializes the manifest object from the provided JSON path.
     *
     * @param path The JSON path.
     * @return The VersionManifest object.
     * @throws IOException exception.
     */
    public static VersionManifest fromPath(final Path path) throws IOException {
        return Util.parseJson(path, CODEC);
    }

    /**
     * Gets the entry for the provided Minecraft version.
     *
     * @param id The Minecraft version ID.
     * @return The entry.
     */
    public Version getVersion(final String id) {
        return Util.findAny(versions, version -> version.id().equals(id));
    }

    /**
     * Gets the entry for the latest release version, if the {@code latest} object is present in the manifest.
     *
     * @return The latest release. Throws if the {@code latest} is not in the manifest.
     */
    public Version latestRelease() {
        final String id = latest.orElseThrow().release();
        return getVersion(id);
    }

    /**
     * Gets the entry for the latest snapshot version, if the {@code latest} object is present in the manifest.
     *
     * @return The latest snapshot. Throws if the {@code latest} is not in the manifest.
     */
    public Version latestSnapshot() {
        final String id = latest.orElseThrow().snapshot();
        return getVersion(id);
    }

    /**
     * A block in the Mojang and Omniarchive manifests that hold strings of the latest versions.
     *
     * @param release The latest release version ID.
     * @param snapshot The latest snapshot version ID.
     */
    public record Latest(String release, String snapshot) {
        public static final Codec<Latest> CODEC = Codecs.of(Latest::new,
                stringField(Latest::release, "release"),
                stringField(Latest::snapshot, "snapshot")
        );
    }

    /**
     * Represents a JSON object in the manifest containing data for a particular Minecraft version.
     *
     * @param id The version.
     * @param url The URL path for this version's JSON.
     */
    public record Version(String id, URL url) {
        public static final Codec<Version> CODEC = Codecs.of(Version::new,
                stringField(Version::id, "id"),
                urlField(Version::url, "url")
        );
    }
}
