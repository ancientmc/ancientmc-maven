package com.ancientmc.excavator.object;

import com.ancientmc.commons.Util;
import com.ancientmc.commons.codec.Codecs;
import com.mojang.serialization.Codec;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.ancientmc.commons.codec.FieldCodecs.*;

/**
 * Represents the Version JSON, which contains the download for the asset index JSON, the libraries Minecraft is dependent on to run,
 * and the client and (sometimes) server JARs for a particular Minecraft version.
 * @param assetIndex The object containing the asset index download.
 * @param libraries The list of libraries required by Minecraft.
 * @param downloads The object containing the client and server downloads (JARs and/or obfuscation mappings).
 * @author moist-mason
 */
public record VersionJson(
        Downloads downloads,
        List<Library> libraries,
        AssetIndexEntry assetIndex) {

    public static final Codec<VersionJson> CODEC = Codecs.of(VersionJson::new,
            field(VersionJson::downloads, "downloads", Downloads.CODEC),
            listField(VersionJson::libraries, "libraries", Library.CODEC),
            field(VersionJson::assetIndex, "assetIndex", AssetIndexEntry.CODEC)
    );

    /**
     * Deserializes the version JSON object from the provided JSON path.
     *
     * @param path The JSON path.
     * @return The version JSON object.
     * @throws IOException exception.
     */
    public static VersionJson fromPath(Path path) throws IOException {
        return Util.parseJson(path, CODEC);
    }

    /**
     * Gets the URL of the client JAR for the version.
     *
     * @return The URL.
     */
    public URL client() {
        return downloads.client().url();
    }

    /**
     * Gets the URL of the server JAR for the version. Throws if the URL is not present in the JSON.
     *
     * @return The URL.
     */
    public URL server() {
        return downloads.server().orElseThrow().url();
    }

    /**
     * Gets the URL of the client obfuscation mappings for the version. Throws if the URL is not present in the JSON.
     *
     * @return The URL.
     */
    public URL clientMappings() {
        return downloads.clientMappings().orElseThrow().url();
    }

    /**
     * Gets the URL of the server obfuscation mappings for the version. Throws if the URL is not present in the JSON.
     *
     * @return The URL.
     */
    public URL serverMappings() {
        return downloads.serverMappings().orElseThrow().url();
    }

    /**
     * Gets a list of the library path names for the version, AKA the maven short name -> {@code group.sub:name:version}.
     * For versions prior to 1.19, this only returns class libraries.
     * Due to changes in the JSON structure, for versions after 1.19 this will return both class libraries and natives.
     *
     * @return The names.
     */
    public List<String> libraryNames() {
        return libraries.stream()
                .map(Library::name)
                .distinct() // some duplicate entries are present in older JSONs, for whatever reason. Remove them.
                .toList();
    }

    /**
     * Gets a map of the class library URLs, with the values being the relative artifact path.
     *
     * @return The URLs.
     */
    public Map<URL, String> libraryUrls() {
        return libraries.stream()
                .map(Library::libraryArtifacts)
                .flatMap(List::stream)
                .distinct() // some duplicate entries are present in older JSONs, for whatever reason. Remove them.
                .collect(Collectors.toMap(Library.Artifact::url, Library.Artifact::path));
    }

    /**
     * Gets a map of the native library URLs, with the values being the relative artifact path.
     *
     * @return The URLs.
     */
    public Map<URL, String> nativeUrls() {
        return libraries.stream()
                .map(Library::nativeArtifacts)
                .flatMap(List::stream)
                .distinct() // some duplicate entries are present in older JSONs, for whatever reason. Remove them.
                .collect(Collectors.toMap(Library.Artifact::url, Library.Artifact::path));
    }

    /**
     * Gets the URL of the asset index.
     *
     * @return The asset index URL.
     */
    public URL assetIndexUrl() {
        return assetIndex.url();
    }

    /**
     * Contains JAR and obfuscation mapping downloads. Different versions contain different download artifacts.
     *
     * @param client Download information for the client JAR. Present in *all* JSONs.
     * @param server Download information for the server JAR. Present in *most* JSONs, but may not be present in older versions.
     * @param clientMappings Download information for the client ProGuard mappings. Only present in ~1.15 to 1.2.11 JSONs.
     * @param serverMappings Download information for the server ProGuard mappings. Only present in ~1.15 to 1.2.11 JSONs.
     */
    public record Downloads(
            Jar client,
            Optional<Jar> server,
            Optional<Mappings> clientMappings,
            Optional<Mappings> serverMappings
    ) {
        public static final Codec<Downloads> CODEC = Codecs.of(Downloads::new,
                field(Downloads::client, "client", Jar.CODEC),
                optionalField(Downloads::server, "server", Jar.CODEC),
                optionalField(Downloads::clientMappings, "client_mappings", Mappings.CODEC),
                optionalField(Downloads::serverMappings, "server_mappings", Mappings.CODEC)
        );

        /**
         * An object representing the JAR downloads.
         *
         * @param url The URL for the JAR.
         */
        public record Jar(URL url) {
            public static final Codec<Jar> CODEC = Codecs.of(Jar::new,
                    urlField(Jar::url, "url")
            );
        }

        /**
         * An object representing the obfuscation mapping downloads.
         *
         * @param url The URL for the mappings.
         */
        public record Mappings(URL url) {
            public static final Codec<Mappings> CODEC = Codecs.of(Mappings::new,
                    urlField(Mappings::url, "url")
            );
        }
    }

    /**
     * An object containing download information for the asset index.
     *
     * @param id The index version. Usually different from the Minecraft version.
     * @param url The index URL.
     */
    public record AssetIndexEntry(String id, URL url) {
        public static final Codec<AssetIndexEntry> CODEC = Codecs.of(AssetIndexEntry::new,
                stringField(AssetIndexEntry::id, "id"),
                urlField(AssetIndexEntry::url, "url")
        );
    }
}
