package com.ancientmc.excavator.object;

import com.ancientmc.commons.Util;
import com.ancientmc.commons.codec.Codecs;
import com.mojang.serialization.Codec;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Path;
import java.util.Map;
import java.util.Optional;

import static com.ancientmc.commons.codec.FieldCodecs.*;

/**
 * The asset index contains data for Minecraft's server-downloaded assets, primarily sounds.
 *
 * @param objects The map of the assets. Each key is the file path of a particular asset. Each value is a subobject containing
 * the encoded hash of the file that gets downloaded from Mojang's servers.
 */
public record AssetIndex(Map<String, Asset> objects) {
    public static final Codec<AssetIndex> CODEC = Codecs.of(AssetIndex::new,
            mapField(AssetIndex::objects, "objects", Codec.STRING, Asset.CODEC)
    );

    /**
     * Deserializes the asset index JSON object from the provided JSON path.
     *
     * @param path The JSON path.
     * @return The asset index object.
     * @throws IOException exception.
     */
    public static AssetIndex fromPath(final Path path) throws IOException {
        return Util.parseJson(path, CODEC);
    }

    /**
     * Represents the object containing the hash information of the asset. In OmniArchive's index files, some assets contain a
     * URL entry. These are only for objects that are downloaded from OmniArchive's servers. Otherwise, The hash gets downloaded from
     * Minecraft's website.
     *
     * @param hash The hash.
     * @param urlPath A URL path for OmniArchive-only assets.
     */
    public record Asset(String hash, Optional<String> urlPath) {
        public static final Codec<Asset> CODEC = Codecs.of(Asset::new,
                stringField(Asset::hash, "hash"),
                optionalStringField(Asset::urlPath, "url")
        );

        /**
         * Formats and returns the URL of this asset.
         *
         * @return The URL.
         */
        public URL url() {
            final String path = hash.substring(0, 2) + '/' + hash;
            final String domain = urlPath.isPresent()
                    ? "https://meta.omniarchive.uk/resources/"
                    : "https://resources.download.minecraft.net/";
            return Util.URL.apply(domain + path);
        }
    }
}
